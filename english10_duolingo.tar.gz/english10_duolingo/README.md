# English10 — bản chạy thật

## Chạy
```bash
cd "/home/ubuntu/Thay Tam/english10_duolingo"
python3 server.py
```
Mở `http://127.0.0.1:8090`.

## Tài khoản quản trị ban đầu
- Email: `admin@lingo10.vn`
- Mật khẩu: `Admin@123`

Tài khoản học sinh đăng ký được lưu trong SQLite `english10.db`. API thật gồm đăng ký, đăng nhập, đăng xuất, quên mật khẩu/cấp lại mật khẩu, bài học, lưu kết quả và thống kê quản trị.

**Lưu ý bảo mật:** đổi mật khẩu quản trị ngay khi triển khai. Luồng reset hiện in mã xác thực ở log máy chủ để chạy nội bộ; khi đưa lên Internet cần nối SMTP hoặc dịch vụ email. Google OAuth cần tạo Client ID/Secret và cấu hình callback; không nên giả lập Google OAuth bằng dữ liệu phía trình duyệt.
