#!/usr/bin/env python3
import hashlib, hmac, json, os, secrets, sqlite3, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

ROOT=os.path.dirname(os.path.abspath(__file__))
DB=os.path.join(ROOT,'english10.db')
HOST='0.0.0.0'; PORT=int(os.environ.get('PORT','8090'))


def db():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row
    c.execute('PRAGMA foreign_keys=ON'); return c

def hash_pw(p,salt=None):
    salt=salt or secrets.token_bytes(16)
    return salt.hex()+':'+hashlib.pbkdf2_hmac('sha256',p.encode(),salt,210000).hex()
def check_pw(p,stored):
    try:
        s,h=stored.split(':'); salt=bytes.fromhex(s)
        return hmac.compare_digest(hash_pw(p,salt).split(':')[1],h)
    except Exception:return False

def seed_curriculum(c):
    units=[
      ('u1','Unit 1: Family life','Family life'),('u2','Unit 2: Humans and the environment','Humans and the environment'),
      ('u3','Unit 3: Music','Music'),('u4','Unit 4: For a better community','For a better community'),
      ('u5','Unit 5: Inventions','Inventions'),('u6','Unit 6: Gender equality','Gender equality'),
      ('u7','Unit 7: Viet Nam and international organisations','Viet Nam and international organisations'),
      ('u8','Unit 8: New ways to learn','New ways to learn'),('u9','Unit 9: Protecting the environment','Protecting the environment'),
      ('u10','Unit 10: Ecotourism','Ecotourism')]
    activities={
      'u1':('household chores','Who usually does the cooking in your family?','I help my family with household chores.'),
      'u2':('green lifestyle','What can students do to protect the environment?','We should reduce plastic waste and save energy.'),
      'u3':('music','What kind of music do you enjoy?','Music helps me relax and connect with other people.'),
      'u4':('volunteering','Why do people volunteer?','Volunteers help people in need and improve their community.'),
      'u5':('smartphone','How does a smartphone help students learn?','It gives students quick access to useful information.'),
      'u6':('equal opportunity','What does gender equality mean?','Everyone should have equal opportunities at school and work.'),
      'u7':('international cooperation','What does Viet Nam contribute to international cooperation?','Viet Nam works with other countries to build peace and development.'),
      'u8':('online learning','What is one advantage of online learning?','Learners can study flexibly and review lessons at their own pace.'),
      'u9':('biodiversity','Why should we protect biodiversity?','Biodiversity keeps ecosystems healthy and supports human life.'),
      'u10':('responsible tourism','How can tourists protect a destination?','Tourists should respect local people, wildlife and the environment.')}
    module_specs=[('Vocabulary','vocabulary'),('Reading','reading'),('Listening','listening'),('Speaking','speaking'),('Writing','writing')]
    for ui,(uid,title,topic) in enumerate(units,1):
        c.execute('INSERT OR IGNORE INTO lessons(id,title,unit,content_json) VALUES(?,?,?,?,?)'.replace('VALUES(?,?,?,?,?)','VALUES(?,?,?,?)'),(uid,title,f'Unit {ui}',json.dumps({'source':'KNTT Global Success 10','status':'adapted_practice','topic':topic},ensure_ascii=False)))
        key,question,model=activities[uid]
        for mi,(skill,kind) in enumerate(module_specs,1):
            mid=f'{uid}-m{mi}'; c.execute('INSERT OR IGNORE INTO modules(id,lesson_id,title,skill,minutes,sort_order) VALUES(?,?,?,?,?,?)',(mid,uid,skill,skill.lower(),5,mi))
            prompts=[f'Choose the best meaning of “{key}”.',question,f'Complete a short {skill.lower()} task about {key}.']
            answers=[key,f'{topic}',model]
            for ii in range(3):
                iid=f'{mid}-i{ii+1}'; typ='mcq' if ii==0 else ('audio' if kind=='listening' else ('recording' if kind=='speaking' else ('text' if kind=='writing' else 'short_answer')))
                opts=[key,'an unrelated idea','a difficult problem','a school subject'] if ii==0 else []
                c.execute('INSERT OR IGNORE INTO items(id,module_id,item_type,prompt,answer,options_json,media_url,rubric_json,sort_order) VALUES(?,?,?,?,?,?,?,?,?)',(iid,mid,typ,prompts[ii],answers[ii],json.dumps(opts,ensure_ascii=False),None,json.dumps({'accuracy':40,'vocabulary':20,'grammar':20,'communication':20} if kind in ('speaking','writing') else {},ensure_ascii=False),ii+1))

def init():
    c=db(); c.executescript('''
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,email TEXT UNIQUE NOT NULL,name TEXT NOT NULL,password_hash TEXT,role TEXT NOT NULL DEFAULT 'student',google_sub TEXT UNIQUE,verified INTEGER NOT NULL DEFAULT 0,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,expires INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS reset_tokens(token TEXT PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,expires INTEGER NOT NULL,used INTEGER DEFAULT 0);
    CREATE TABLE IF NOT EXISTS attempts(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL REFERENCES users(id),lesson_id TEXT NOT NULL,score REAL NOT NULL,duration INTEGER DEFAULT 0,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS lessons(id TEXT PRIMARY KEY,title TEXT NOT NULL,unit TEXT NOT NULL,content_json TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS modules(id TEXT PRIMARY KEY,lesson_id TEXT NOT NULL REFERENCES lessons(id) ON DELETE CASCADE,title TEXT NOT NULL,skill TEXT NOT NULL,minutes INTEGER DEFAULT 5,sort_order INTEGER DEFAULT 0);
    CREATE TABLE IF NOT EXISTS items(id TEXT PRIMARY KEY,module_id TEXT NOT NULL REFERENCES modules(id) ON DELETE CASCADE,item_type TEXT NOT NULL,prompt TEXT NOT NULL,answer TEXT,options_json TEXT,media_url TEXT,rubric_json TEXT,sort_order INTEGER DEFAULT 0);
    CREATE TABLE IF NOT EXISTS progress(user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,lesson_id TEXT NOT NULL REFERENCES lessons(id) ON DELETE CASCADE,completed INTEGER DEFAULT 0,best_score REAL DEFAULT 0,seconds INTEGER DEFAULT 0,updated_at TEXT DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(user_id,lesson_id));
    ''')
    admin=c.execute('SELECT id FROM users WHERE email=?',('admin@lingo10.vn',)).fetchone()
    if not admin:c.execute('INSERT INTO users(email,name,password_hash,role,verified) VALUES(?,?,?,?,1)',('admin@lingo10.vn','Quản trị viên',hash_pw('Admin@123'),'admin'))
    lessons=[('u1-vocab','Vocabulary','Unit 1: Family life',json.dumps({'questions':[{'word':'household chores','answer':'công việc nhà','options':['môn học','công việc nhà','thời gian rảnh','bữa ăn']},{'word':'responsible','answer':'có trách nhiệm','options':['có trách nhiệm','sáng tạo','thân thiện','tiết kiệm']},{'word':'environment','answer':'môi trường','options':['gia đình','môi trường','âm nhạc','sức khoẻ']}]}))]
    for x in lessons:c.execute('INSERT OR IGNORE INTO lessons VALUES(?,?,?,?)',x)
    seed_curriculum(c)
    c.commit(); c.close()

def body(h):
    n=int(h.headers.get('Content-Length','0')); return json.loads(h.rfile.read(n) or b'{}')
def send(h,status,data,headers=None):
    raw=json.dumps(data,ensure_ascii=False).encode(); h.send_response(status); h.send_header('Content-Type','application/json; charset=utf-8'); h.send_header('Content-Length',str(len(raw)))
    for k,v in (headers or {}).items():h.send_header(k,v)
    h.end_headers();h.wfile.write(raw)
def user(h):
    tok=h.headers.get('Cookie','').replace('session=','').split(';')[0].strip()
    if not tok:return None
    c=db(); r=c.execute('SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=? AND s.expires>?',(tok,int(time.time()))).fetchone();c.close();return r

class App(BaseHTTPRequestHandler):
    def log_message(self,*a):pass
    def do_GET(self):
        p=urlparse(self.path).path
        if p=='/api/me':
            u=user(self); return send(self,200,{'user':dict(u) if u else None})
        if p=='/api/lessons':
            c=db(); rows=[dict(x) for x in c.execute('SELECT id,title,unit FROM lessons')];c.close();return send(self,200,{'lessons':rows})
        if p.startswith('/api/lesson/'):
            lid=p.split('/')[-1]; c=db(); l=c.execute('SELECT id,title,unit,content_json FROM lessons WHERE id=?',(lid,)).fetchone()
            if not l:c.close();return send(self,404,{'error':'lesson_not_found'})
            mods=[dict(x) for x in c.execute('SELECT id,title,skill,minutes,sort_order FROM modules WHERE lesson_id=? ORDER BY sort_order',(lid,))]
            for m in mods:m['items']=[dict(x) for x in c.execute('SELECT id,item_type,prompt,answer,options_json,media_url,rubric_json FROM items WHERE module_id=? ORDER BY sort_order',(m['id'],))]
            c.close();return send(self,200,{'lesson':dict(l),'modules':mods})
        if p=='/api/progress':
            u=user(self)
            if not u:return send(self,401,{'error':'unauthorized'})
            c=db(); rows=[dict(x) for x in c.execute('SELECT p.*,l.title,l.unit FROM progress p JOIN lessons l ON l.id=p.lesson_id WHERE p.user_id=? ORDER BY p.updated_at DESC',(u['id'],))]; agg=c.execute('SELECT COUNT(*) attempts,COALESCE(AVG(score),0) average,COALESCE(SUM(duration),0) seconds FROM attempts WHERE user_id=?',(u['id'],)).fetchone(); today=c.execute("SELECT COUNT(*) attempts,COALESCE(AVG(score),0) average,COALESCE(SUM(duration),0) seconds FROM attempts WHERE user_id=? AND created_at >= date('now','start of day')",(u['id'],)).fetchone(); week=c.execute("SELECT COALESCE(SUM(duration),0) seconds FROM attempts WHERE user_id=? AND created_at >= datetime('now','-7 day')",(u['id'],)).fetchone(); out={'progress':rows,'summary':{'attempts':agg['attempts'],'average':round(agg['average'],1),'seconds':agg['seconds'],'completed':sum(1 for x in rows if x['completed']),'today_attempts':today['attempts'],'today_average':round(today['average'],1),'today_seconds':today['seconds'],'today_xp':round(today['average']*today['attempts']/5),'week_seconds':week['seconds'],'week_goal_seconds':1200}};c.close();return send(self,200,out)
        if p.startswith('/api/admin/'):
            u=user(self)
            if not u or u['role']!='admin':return send(self,403,{'error':'forbidden'})
            c=db()
            if p=='/api/admin/stats':
                out={'students':c.execute("SELECT COUNT(*) n FROM users WHERE role='student'").fetchone()['n'],'attempts':c.execute('SELECT COUNT(*) n FROM attempts').fetchone()['n'],'average':round(c.execute('SELECT COALESCE(AVG(score),0) n FROM attempts').fetchone()['n'],2),'active_7d':c.execute("SELECT COUNT(DISTINCT user_id) n FROM attempts WHERE created_at >= datetime('now','-7 day')").fetchone()['n']}
            elif p=='/api/admin/lessons':
                out={'lessons':[dict(x) for x in c.execute('SELECT id,title,unit,content_json FROM lessons ORDER BY unit,title')]}
            elif p=='/api/admin/students':
                out={'students':[dict(x) for x in c.execute("SELECT u.id,u.email,u.name,u.created_at,COUNT(a.id) attempts,COALESCE(AVG(a.score),0) average FROM users u LEFT JOIN attempts a ON a.user_id=u.id WHERE u.role='student' GROUP BY u.id ORDER BY u.created_at DESC")]}
            elif p=='/api/admin/attempts':
                out={'attempts':[dict(x) for x in c.execute("SELECT a.id,u.email,u.name,a.lesson_id,a.score,a.duration,a.created_at FROM attempts a JOIN users u ON u.id=a.user_id ORDER BY a.created_at DESC LIMIT 200")]}
            else:c.close();return send(self,404,{'error':'not_found'})
            c.close();return send(self,200,out)
        if p=='/' or p=='/index.html':
            try:data=open(os.path.join(ROOT,'index.html'),'rb').read()
            except FileNotFoundError:return send(self,404,{'error':'missing index'})
            self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data);return
        return send(self,404,{'error':'not_found'})
    def do_POST(self):
        p=urlparse(self.path).path; d=body(self); c=db()
        try:
            if p=='/api/register':
                e=d.get('email','').strip().lower(); name=d.get('name','').strip() or e.split('@')[0]; pw=d.get('password','')
                if '@' not in e or len(pw)<6:return send(self,400,{'error':'Email hợp lệ và mật khẩu ít nhất 6 ký tự'})
                c.execute('INSERT INTO users(email,name,password_hash,role,verified) VALUES(?,?,?,?,1)',(e,name,hash_pw(pw),'student'));c.commit();return self.login(c,e,pw)
            if p=='/api/login':return self.login(c,d.get('email','').lower().strip(),d.get('password',''))
            if p=='/api/logout':
                tok=self.headers.get('Cookie','').replace('session=','').split(';')[0].strip();c.execute('DELETE FROM sessions WHERE token=?',(tok,));c.commit();return send(self,200,{'ok':True}, {'Set-Cookie':'session=; Max-Age=0; Path=/; HttpOnly; SameSite=Lax'})
            if p=='/api/forgot':
                e=d.get('email','').lower().strip();r=c.execute('SELECT id FROM users WHERE email=? AND role="student"',(e,)).fetchone()
                if not r:return send(self,200,{'ok':True,'message':'Nếu tài khoản tồn tại, mã xác thực đã được gửi.'})
                code=str(secrets.randbelow(900000)+100000);token=secrets.token_urlsafe(24);c.execute('INSERT INTO reset_tokens VALUES(?,?,?,0)',(token,r['id'],int(time.time())+900));c.commit();print(f'[RESET CODE for {e}] {code} token={token}',flush=True);return send(self,200,{'ok':True,'message':'Mã xác thực đã được gửi.','reset_token':token,'demo_code':code})
            if p=='/api/reset':
                r=c.execute('SELECT * FROM reset_tokens WHERE token=? AND used=0 AND expires>?',(d.get('token',''),int(time.time()))).fetchone()
                if not r or d.get('code')!=d.get('expected_code') or len(d.get('password',''))<6:return send(self,400,{'error':'Mã hoặc liên kết không hợp lệ'})
                c.execute('UPDATE users SET password_hash=? WHERE id=?',(hash_pw(d['password']),r['user_id']));c.execute('UPDATE reset_tokens SET used=1 WHERE token=?',(r['token'],));c.commit();return send(self,200,{'ok':True})
            if p.startswith('/api/admin/'):
                u=user(self)
                if not u or u['role']!='admin':return send(self,403,{'error':'forbidden'})
                if p in ('/api/admin/lessons/create','/api/admin/lessons/update','/api/admin/lessons/delete'):
                    lid=d.get('id','').strip()
                    if p.endswith('/create'):
                        if not lid or not d.get('title') or not d.get('unit'):return send(self,400,{'error':'Thiếu mã, tiêu đề hoặc Unit'})
                        content=d.get('content_json') or json.dumps({'questions':[]},ensure_ascii=False)
                        c.execute('INSERT INTO lessons(id,title,unit,content_json) VALUES(?,?,?,?)',(lid,d['title'],d['unit'],content));c.commit();return send(self,201,{'ok':True})
                    if not lid:return send(self,400,{'error':'Thiếu mã bài học'})
                    if p.endswith('/delete'):
                        c.execute('DELETE FROM lessons WHERE id=?',(lid,));c.commit();return send(self,200,{'ok':True})
                    c.execute('UPDATE lessons SET title=?,unit=?,content_json=? WHERE id=?',(d.get('title'),d.get('unit'),d.get('content_json','{"questions":[]}'),lid));c.commit();return send(self,200,{'ok':True})
                if p in ('/api/admin/modules/create','/api/admin/modules/update','/api/admin/modules/delete'):
                    mid=d.get('id','').strip()
                    if p.endswith('/create'):
                        c.execute('INSERT INTO modules(id,lesson_id,title,skill,minutes,sort_order) VALUES(?,?,?,?,?,?)',(mid,d['lesson_id'],d['title'],d['skill'],int(d.get('minutes',5)),int(d.get('sort_order',0))));c.commit();return send(self,201,{'ok':True})
                    if p.endswith('/delete'):c.execute('DELETE FROM modules WHERE id=?',(mid,));c.commit();return send(self,200,{'ok':True})
                    c.execute('UPDATE modules SET title=?,skill=?,minutes=?,sort_order=? WHERE id=?',(d['title'],d['skill'],int(d.get('minutes',5)),int(d.get('sort_order',0)),mid));c.commit();return send(self,200,{'ok':True})
                if p in ('/api/admin/items/create','/api/admin/items/update','/api/admin/items/delete'):
                    iid=d.get('id','').strip()
                    if p.endswith('/create'):
                        c.execute('INSERT INTO items(id,module_id,item_type,prompt,answer,options_json,media_url,rubric_json,sort_order) VALUES(?,?,?,?,?,?,?,?,?)',(iid,d['module_id'],d['item_type'],d['prompt'],d.get('answer'),json.dumps(d.get('options',[]),ensure_ascii=False),d.get('media_url'),json.dumps(d.get('rubric',{}),ensure_ascii=False),int(d.get('sort_order',0))));c.commit();return send(self,201,{'ok':True})
                    if p.endswith('/delete'):c.execute('DELETE FROM items WHERE id=?',(iid,));c.commit();return send(self,200,{'ok':True})
                    c.execute('UPDATE items SET item_type=?,prompt=?,answer=?,options_json=?,media_url=?,rubric_json=?,sort_order=? WHERE id=?',(d['item_type'],d['prompt'],d.get('answer'),json.dumps(d.get('options',[]),ensure_ascii=False),d.get('media_url'),json.dumps(d.get('rubric',{}),ensure_ascii=False),int(d.get('sort_order',0)),iid));c.commit();return send(self,200,{'ok':True})
            if p=='/api/attempt':
                u=user(self)
                if not u:return send(self,401,{'error':'unauthorized'})
                lid=d.get('lesson_id','u1-vocab');score=float(d.get('score',0));secs=int(d.get('duration',0));c.execute('INSERT INTO attempts(user_id,lesson_id,score,duration) VALUES(?,?,?,?)',(u['id'],lid,score,secs));c.execute('INSERT INTO progress(user_id,lesson_id,completed,best_score,seconds) VALUES(?,?,?,?,?) ON CONFLICT(user_id,lesson_id) DO UPDATE SET completed=excluded.completed,best_score=MAX(progress.best_score,excluded.best_score),seconds=progress.seconds+excluded.seconds,updated_at=CURRENT_TIMESTAMP',(u['id'],lid,int(d.get('completed',1)),score,secs));c.commit();return send(self,200,{'ok':True})
            return send(self,404,{'error':'not_found'})
        except sqlite3.IntegrityError:return send(self,409,{'error':'Email đã tồn tại'})
        finally:c.close()
    def login(self,c,e,p):
        r=c.execute('SELECT * FROM users WHERE email=?',(e,)).fetchone()
        if not r or not r['password_hash'] or not check_pw(p,r['password_hash']):return send(self,401,{'error':'Email hoặc mật khẩu không đúng'})
        tok=secrets.token_urlsafe(32);c.execute('INSERT INTO sessions VALUES(?,?,?)',(tok,r['id'],int(time.time())+86400*14));c.commit();return send(self,200,{'user':dict(r)}, {'Set-Cookie':f'session={tok}; Max-Age=1209600; Path=/; HttpOnly; SameSite=Lax'})

if __name__=='__main__':
    init();print(f'English10 server: http://127.0.0.1:{PORT}',flush=True);ThreadingHTTPServer((HOST,PORT),App).serve_forever()
